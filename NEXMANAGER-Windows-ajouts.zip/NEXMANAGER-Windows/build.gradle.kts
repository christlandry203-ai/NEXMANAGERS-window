import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "1.9.24"
    id("org.jetbrains.compose") version "1.6.11"
}

group = "com.nexcode.nexmanager"
version = "1.2.0"

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.8.1")
}

compose.desktop {
    application {
        mainClass = "com.nexcode.nexmanager.MainKt"

        nativeDistributions {
            // .exe (installateur) + .msi ; le runtime Java est inclus : rien à installer pour l'utilisateur.
            targetFormats(TargetFormat.Exe, TargetFormat.Msi)
            packageName = "NEXMANAGER"
            packageVersion = "1.2.0"
            description = "NEXMANAGER - gestionnaire de fichiers by NEXCODE"
            vendor = "NEXCODE"
            copyright = "© NEXCODE"
            includeAllModules = true

            windows {
                iconFile.set(project.file("icons/nexmanager.ico"))
                menuGroup = "NEXCODE"
                shortcut = true
                menu = true
                dirChooser = true
                perUserInstall = true
                // Identifiant fixe : les futures versions se mettent à jour par-dessus l'ancienne.
                upgradeUuid = "6f1c2b7e-3a5d-4c8f-9e21-4d7b0a95c3e1"
            }
        }
    }
}
