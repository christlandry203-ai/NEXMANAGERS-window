package com.nexcode.nexmanager

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

/** Fenêtre large (cas normal sur PC) : navigation latérale et deux panneaux. Sous 720 dp : mise en page compacte. */
@Composable
fun isWideLayout(): Boolean = LocalWindowWidthDp.current >= 720f

/** Très grand écran : ajoute le panneau de détails à droite. */
@Composable
fun isExtraWideLayout(): Boolean = LocalWindowWidthDp.current >= 1000f

/** Clic droit de la souris (menu contextuel). */
fun Modifier.onRightClick(onClick: () -> Unit): Modifier = this.pointerInput(onClick) {
    awaitPointerEventScope {
        while (true) {
            val event = awaitPointerEvent()
            if (event.type == PointerEventType.Press && event.buttons.isSecondaryPressed) {
                event.changes.forEach { it.consume() }
                onClick()
            }
        }
    }
}

@Composable
fun Breadcrumb(vm: MainViewModel, modifier: Modifier = Modifier) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val rel = vm.dir.absolutePath.removePrefix(vm.base.absolutePath).trim('/')
    val parts = if (rel.isEmpty()) emptyList() else rel.split('/')
    Row(modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
        Text(
            vm.baseLabel,
            Modifier.clip(RoundedCornerShape(6.dp)).clickable { vm.openDir(vm.base) }.padding(horizontal = 6.dp, vertical = 4.dp),
            fontWeight = FontWeight.SemiBold, maxLines = 1
        )
        var acc = vm.base
        for (p in parts) {
            acc = File(acc, p)
            val target = acc
            Text("›", color = muted)
            Text(
                p,
                Modifier.clip(RoundedCornerShape(6.dp)).clickable { vm.openDir(target) }.padding(horizontal = 6.dp, vertical = 4.dp),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SideHeader(text: String) {
    Text(
        text, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 4.dp)
    )
}

@Composable
private fun SideItem(emoji: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) NexBlue.copy(alpha = 0.22f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Text(
            label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

/** Panneau de gauche : emplacements, accès rapide et catégories. */
@Composable
fun FilesSidebar(vm: MainViewModel, modifier: Modifier = Modifier) {
    @Suppress("DEPRECATION")
    val quick = listOf(
        Triple("📦", "Téléchargements", KnownDirs.DOWNLOADS),
        Triple("📄", "Documents", KnownDirs.DOCUMENTS),
        Triple("🖥️", "Bureau", KnownDirs.DESKTOP),
        Triple("🖼️", "Images", KnownDirs.PICTURES),
        Triple("🎬", "Films", KnownDirs.VIDEOS),
        Triple("🎵", "Musique", KnownDirs.MUSIC)
    )
    val cats = listOf(
        Triple("🖼️", "Toutes les images", "images"),
        Triple("🎬", "Toutes les vidéos", "videos"),
        Triple("🎵", "Toute la musique", "audio"),
        Triple("📄", "Tous les documents", "documents")
    )
    Column(
        modifier.background(MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState()).padding(vertical = 8.dp)
    ) {
        SideHeader("EMPLACEMENTS")
        for (v in vm.volumes) {
            SideItem(v.emoji, v.label, vm.category == null && vm.base.absolutePath == v.dir.absolutePath) { vm.goToVolume(v) }
        }
        SideHeader("ACCÈS RAPIDE")
        for ((emoji, label, type) in quick) {
            SideItem(emoji, label, false) { vm.browse(type) }
        }
        SideHeader("CATÉGORIES")
        for ((emoji, label, kind) in cats) {
            SideItem(emoji, label, vm.category == kind) { vm.openCategory(kind) }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Column(Modifier.padding(bottom = 8.dp)) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 13.sp)
    }
}

@Composable
private fun DetailAction(label: String, danger: Boolean = false, onClick: () -> Unit) {
    Text(
        label,
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        fontSize = 14.sp,
        color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
    )
}

/** Panneau de droite : détails et actions de l'élément sélectionné. */
@Composable
fun DetailsPane(
    vm: MainViewModel,
    f: File,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.background(MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Text("Détails", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Text(FileRepo.emoji(f), fontSize = 56.sp) }
        Spacer(Modifier.height(8.dp))
        Text(f.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Spacer(Modifier.height(10.dp))
        InfoLine("Type", FileRepo.kind(f))
        InfoLine(
            "Taille",
            if (f.isFile) FileRepo.humanSize(f.length()) else "${f.list()?.size ?: 0} élément(s)"
        )
        InfoLine("Modifié le", FileRepo.date(f.lastModified()))
        InfoLine("Emplacement", f.parent ?: "")
        Spacer(Modifier.height(10.dp))
        GradientButton(if (f.isDirectory) "📂  Ouvrir le dossier" else "↗️  Ouvrir", onOpen, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        if (f.isFile) DetailAction("📂  Afficher dans l'Explorateur", onClick = onShare)
        DetailAction("📋  Copier") { vm.copyToClip(f) }
        DetailAction("✂️  Déplacer") { vm.cutToClip(f) }
        DetailAction("✏️  Renommer", onClick = onRename)
        DetailAction("🗑️  Supprimer", true, onDelete)
    }
}
