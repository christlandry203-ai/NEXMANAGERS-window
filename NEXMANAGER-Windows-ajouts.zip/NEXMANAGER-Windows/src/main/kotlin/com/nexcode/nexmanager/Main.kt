package com.nexcode.nexmanager

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isAltPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPosition
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import java.awt.Dimension
import java.awt.event.WindowAdapter
import java.awt.event.WindowEvent
import javax.swing.UIManager

/** Point d'entrée Windows : remplace MainActivity (fenêtre, thème, permissions inutiles sous Windows). */
fun main() {
    try {
        // Boîtes de dialogue (sélecteur de dossier) au style Windows
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName())
    } catch (e: Exception) {
        // style par défaut
    }
    application {
        val vm = remember { MainViewModel() }
        val state = rememberWindowState(
            size = DpSize(1180.dp, 760.dp),
            position = WindowPosition.Aligned(Alignment.Center)
        )
        Window(
            onCloseRequest = {
                vm.shutdown()
                exitApplication()
            },
            title = "NEXMANAGER",
            state = state,
            icon = painterResource("nexmanager.png"),
            // Alt + ← : équivalent du bouton Retour d'Android
            onKeyEvent = { e -> e.type == KeyEventType.KeyDown && e.isAltPressed && e.key == Key.DirectionLeft && handleBack() }
        ) {
            LaunchedEffect(Unit) { window.minimumSize = Dimension(420, 520) }

            // Équivalent de onResume : on recharge la liste quand la fenêtre reprend le focus.
            DisposableEffect(window) {
                val listener = object : WindowAdapter() {
                    override fun windowGainedFocus(e: WindowEvent?) { vm.refresh() }
                }
                window.addWindowFocusListener(listener)
                onDispose { window.removeWindowFocusListener(listener) }
            }
            LaunchedEffect(Unit) { vm.refresh() }

            CompositionLocalProvider(LocalWindowWidthDp provides state.size.width.value) {
                NexTheme(vm.dark) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        NexApp(vm, onPickTree = { pickFolder(window, vm.dir)?.let { vm.transferToFolder(it) } })
                    }
                }
            }
        }
    }
}
