package com.nexcode.nexmanager

import kotlinx.coroutines.CancellationException
import java.io.File
import java.io.IOException

/** Moteur de transfert : flux de 64 Ko (peu de RAM), progression, annulation. Tout se passe sur un thread IO. */
object Transfer {

    private class Tracker(
        private val total: Long,
        private val publish: (String, Long, Long) -> Unit,
        private val cancelled: () -> Boolean
    ) {
        private var done = 0L
        private var last = 0L
        fun add(n: Long, name: String) {
            if (cancelled()) throw CancellationException("Transfert annulé")
            done += n
            val now = System.nanoTime()
            if (now - last > 100_000_000L) { last = now; publish(name, done, total) }
        }
    }

    fun sizeOf(f: File): Long =
        if (f.isFile) f.length() else (f.listFiles()?.sumOf { sizeOf(it) } ?: 0L)

    fun friendly(e: Exception): String {
        val m = e.message ?: ""
        return when {
            m.contains("not enough space", true) || m.contains("No space", true) ||
                m.contains("espace", true) && m.contains("disque", true) -> "Espace insuffisant sur la destination."
            e is java.nio.file.AccessDeniedException || m.contains("Access is denied", true) ||
                m.contains("Access denied", true) || m.contains("Accès refusé", true) ||
                m.contains("Permission denied", true) -> "Accès refusé par Windows sur cet emplacement."
            m.contains("being used by another process", true) || m.contains("utilisé par un autre", true) ||
                m.contains("sharing violation", true) -> "Le fichier est utilisé par un autre programme : ferme-le puis réessaie."
            m.contains("read-only", true) || m.contains("lecture seule", true) -> "La destination est en lecture seule."
            else -> "Erreur pendant le transfert : " + m.ifBlank { e.javaClass.simpleName }
        }
    }

    private fun checkLocal(files: List<File>, dest: File): String? {
        if (!FileRepo.isSafe(dest) || !dest.isDirectory) return "Destination invalide."
        if (!dest.canWrite()) {
            return "Ce dossier n'est pas accessible en écriture. Choisis un autre dossier de destination."
        }
        for (f in files) {
            if (!f.exists()) return "« ${f.name} » n'existe plus."
            if (!FileRepo.isSafe(f)) return "Opération refusée sur « ${f.name} »."
            if (f.isDirectory && FileRepo.isInside(dest, f)) {
                return "Impossible de copier un dossier dans lui-même."
            }
        }
        return null
    }

    private fun copyTree(src: File, dst: File, t: Tracker) {
        if (src.isDirectory) {
            if (!dst.mkdirs() && !dst.isDirectory) throw IOException("Création impossible : ${dst.name}")
            src.listFiles()?.forEach { copyTree(it, File(dst, it.name), t) }
        } else {
            src.inputStream().use { i ->
                dst.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        t.add(n.toLong(), src.name)
                    }
                }
            }
            dst.setLastModified(src.lastModified())
        }
    }

    /** Copie / déplacement de fichiers et dossiers vers un dossier accessible directement. Retourne null si OK, sinon l'erreur. */
    fun runLocal(
        files: List<File>, dest: File, cut: Boolean,
        publish: (String, Long, Long) -> Unit, cancelled: () -> Boolean,
        onItem: (Int) -> Unit = {}
    ): String? {
        checkLocal(files, dest)?.let { return it }
        val sizes = files.map { sizeOf(it) }
        val total = sizes.sum()
        if (!cut) {
            val free = dest.usableSpace.let { if (it <= 0L) Long.MAX_VALUE else it }
            if (total > free) return "Espace insuffisant : il manque ${FileRepo.humanSize(total - free)}."
        }
        val t = Tracker(total, publish, cancelled)
        publish("", 0L, total)
        for ((i, f) in files.withIndex()) {
            onItem(i + 1)
            val target = FileRepo.uniqueTarget(dest, f.name)
            try {
                if (cut && f.renameTo(target)) {
                    t.add(sizes[i], f.name)
                } else {
                    copyTree(f, target, t)
                    if (cut && !FileRepo.delete(f)) {
                        return "Copié, mais l'original « ${f.name} » n'a pas pu être supprimé."
                    }
                }
            } catch (e: CancellationException) {
                target.deleteRecursively()
                throw e
            } catch (e: Exception) {
                target.deleteRecursively()
                return friendly(e)
            }
        }
        return null
    }
}
