package com.nexcode.nexmanager

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.rememberUpdatedState
import java.awt.Desktop
import java.awt.Frame
import java.io.File
import java.util.Properties
import javax.swing.JFileChooser

/** Tout ce qui diffère d'Android est regroupé ici : le reste du code reste proche de la version Android. */

const val APP_VERSION = "1.2.0"

/** Équivalent minimal de la classe R d'Android, pour garder les mêmes appels dans les écrans. */
object R {
    object drawable {
        const val ic_nexcode_logo = "ic_nexcode_logo.png"
    }
}

/** Largeur de la fenêtre en dp (remplace LocalConfiguration.screenWidthDp d'Android). */
val LocalWindowWidthDp = compositionLocalOf { 1200f }

// ---------- Retour arrière (remplace le bouton Retour d'Android : Alt + ← ) ----------

object BackStack {
    val handlers = mutableStateListOf<() -> Unit>()
}

@Composable
fun BackHandler(enabled: Boolean = true, onBack: () -> Unit) {
    val current = rememberUpdatedState(onBack)
    DisposableEffect(enabled) {
        if (!enabled) {
            onDispose { }
        } else {
            val h: () -> Unit = { current.value() }
            BackStack.handlers.add(h)
            onDispose { BackStack.handlers.remove(h) }
        }
    }
}

fun handleBack(): Boolean {
    val h = BackStack.handlers.lastOrNull() ?: return false
    h()
    return true
}

// ---------- Messages (remplace les Toast d'Android) ----------

object Notifier {
    @Volatile var notify: (String) -> Unit = {}
}

// ---------- Dossiers connus de Windows (remplace Environment.DIRECTORY_*) ----------

object KnownDirs {
    const val DOWNLOADS = "Downloads"
    const val DOCUMENTS = "Documents"
    const val PICTURES = "Pictures"
    const val VIDEOS = "Videos"
    const val MUSIC = "Music"
    const val DESKTOP = "Desktop"

    /** Le dossier existe sous ce nom (anglais) même sur un Windows en français ; on gère aussi OneDrive. */
    fun resolve(type: String): File? {
        val home = FileRepo.root
        val oneDrive = System.getenv("OneDrive")?.let { File(it) }
        val alt = when (type) {
            DESKTOP -> "Bureau"
            DOCUMENTS -> "Documents"
            PICTURES -> "Images"
            VIDEOS -> "Vidéos"
            MUSIC -> "Musique"
            else -> "Téléchargements"
        }
        val candidates = listOfNotNull(
            File(home, type),
            oneDrive?.let { File(it, type) },
            oneDrive?.let { File(it, alt) },
            File(home, alt)
        )
        return candidates.firstOrNull { it.isDirectory }
    }
}

// ---------- Préférences (remplace SharedPreferences) ----------

object Prefs {
    private val file: File by lazy {
        File(System.getenv("APPDATA") ?: System.getProperty("user.home"), "NEXMANAGER/settings.properties")
    }
    private val props = Properties().apply {
        try {
            if (file.isFile) file.inputStream().use { load(it) }
        } catch (e: Exception) {
            // première utilisation ou fichier illisible : valeurs par défaut
        }
    }

    fun getBoolean(key: String, default: Boolean): Boolean = props.getProperty(key)?.toBooleanStrictOrNull() ?: default
    fun getString(key: String, default: String): String = props.getProperty(key) ?: default
    fun putBoolean(key: String, value: Boolean) = put(key, value.toString())
    fun putString(key: String, value: String) = put(key, value)

    @Synchronized
    private fun put(key: String, value: String) {
        props.setProperty(key, value)
        try {
            file.parentFile?.mkdirs()
            file.outputStream().use { props.store(it, "NEXMANAGER") }
        } catch (e: Exception) {
            // préférence non enregistrée : sans gravité
        }
    }
}

// ---------- Ouvrir / afficher un fichier (remplace Intent.ACTION_VIEW et le partage Android) ----------

fun openFile(f: File) {
    try {
        if (!Desktop.isDesktopSupported()) {
            Notifier.notify("Ouverture impossible sur ce système")
            return
        }
        Desktop.getDesktop().open(f)
    } catch (e: java.io.IOException) {
        Notifier.notify("Aucune application pour ouvrir ce fichier")
    } catch (e: Exception) {
        Notifier.notify("Impossible d'ouvrir ce fichier")
    }
}

/** Équivalent Windows du partage Android : affiche l'élément dans l'Explorateur de fichiers. */
fun revealInExplorer(f: File) {
    try {
        if (f.exists()) {
            ProcessBuilder("explorer.exe", "/select,", f.absolutePath).start()
        } else {
            Notifier.notify("Cet élément n'existe plus")
        }
    } catch (e: Exception) {
        Notifier.notify("Impossible d'ouvrir l'Explorateur")
    }
}

/** Sélecteur de dossier Windows (remplace le sélecteur SAF d'Android). */
fun pickFolder(parent: Frame?, start: File?): File? {
    val chooser = JFileChooser(start ?: FileRepo.root)
    chooser.fileSelectionMode = JFileChooser.DIRECTORIES_ONLY
    chooser.dialogTitle = "Choisir le dossier de destination"
    chooser.approveButtonText = "Choisir ce dossier"
    return if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) chooser.selectedFile else null
}

// ---------- Programmes installés (remplace la liste des applications Android) ----------

object InstalledPrograms {

    private const val SCRIPT =
        "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; " +
            "\$p='HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'," +
            "'HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'," +
            "'HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'; " +
            "Get-ItemProperty \$p -ErrorAction SilentlyContinue | Where-Object { \$_.DisplayName } | " +
            "Select-Object DisplayName,DisplayVersion,Publisher,InstallLocation,EstimatedSize,SystemComponent,ParentKeyName | " +
            "ConvertTo-Csv -NoTypeInformation"

    fun list(): List<AppInfo> {
        return try {
            val proc = ProcessBuilder(
                "powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", SCRIPT
            ).redirectErrorStream(false).start()
            proc.outputStream.close()
            val text = proc.inputStream.readBytes().toString(Charsets.UTF_8)
            proc.waitFor()
            val lines = text.lines().filter { it.isNotBlank() }
            if (lines.size < 2) return emptyList()
            val header = parseCsvLine(lines[0].trimStart('\uFEFF'))
            fun idx(n: String) = header.indexOf(n)
            val iName = idx("DisplayName")
            val iVer = idx("DisplayVersion")
            val iPub = idx("Publisher")
            val iLoc = idx("InstallLocation")
            val iSize = idx("EstimatedSize")
            val iSys = idx("SystemComponent")
            val iParent = idx("ParentKeyName")
            fun cell(c: List<String>, i: Int) = if (i >= 0 && i < c.size) c[i].trim() else ""
            lines.drop(1).mapNotNull { line ->
                val c = parseCsvLine(line)
                val name = cell(c, iName)
                if (name.isEmpty()) return@mapNotNull null
                AppInfo(
                    label = name,
                    pkg = cell(c, iPub).ifEmpty { "Éditeur inconnu" },
                    apk = cell(c, iLoc).trim('"'),
                    version = cell(c, iVer).ifEmpty { "?" },
                    system = cell(c, iSys) == "1" || cell(c, iParent).isNotEmpty(),
                    split = false,
                    size = (cell(c, iSize).toLongOrNull() ?: 0L) * 1024L
                )
            }.distinctBy { it.label + "|" + it.version }.sortedBy { it.label.lowercase() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                inQuotes && ch == '"' && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                ch == '"' -> inQuotes = !inQuotes
                ch == ',' && !inQuotes -> { out.add(sb.toString()); sb.setLength(0) }
                else -> sb.append(ch)
            }
            i++
        }
        out.add(sb.toString())
        return out
    }

    /** Export CSV de la liste (Excel, FR) — équivalent de l'export d'APK d'Android. */
    fun toCsv(apps: List<AppInfo>): String {
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("\uFEFF")
        sb.append("Nom;Version;Éditeur;Taille estimée;Emplacement\r\n")
        for (a in apps) {
            sb.append(q(a.label)).append(';').append(q(a.version)).append(';').append(q(a.pkg)).append(';')
                .append(q(if (a.size > 0) FileRepo.humanSize(a.size) else "")).append(';').append(q(a.apk)).append("\r\n")
        }
        return sb.toString()
    }
}
