package com.nexcode.nexmanager

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import javax.swing.filechooser.FileSystemView

enum class SortBy { NAME, SIZE, DATE }

/**
 * Version Windows. Sur Android, tout est limité au stockage partagé ; ici on gère le dossier personnel
 * et les lecteurs (C:, D:, clés USB…), en protégeant les dossiers système de Windows.
 */
object FileRepo {

    const val HOME_LABEL = "Dossier personnel"

    private val IS_WINDOWS = (System.getProperty("os.name") ?: "").startsWith("Windows", ignoreCase = true)

    /** Dossier personnel de l'utilisateur (équivalent du « stockage interne »). */
    val root: File get() = File(System.getProperty("user.home") ?: "C:\\")

    /** Afficher ou non les fichiers cachés (réglage). */
    @Volatile var showHidden: Boolean = false

    private fun drives(): List<File> = try {
        File.listRoots()?.filter { it.exists() } ?: emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    private fun roots(): List<File> = listOf(root) + drives()

    /** Dossiers que Windows protège : jamais modifiés ni supprimés depuis l'application. */
    private val PROTECTED = listOf(
        "Windows", "Program Files", "Program Files (x86)", "ProgramData",
        "\$Recycle.Bin", "System Volume Information", "Recovery", "Boot"
    )

    fun isInside(child: File, parent: File): Boolean = try {
        val c = child.canonicalPath
        val p = parent.canonicalPath
        c.equals(p, ignoreCase = IS_WINDOWS) ||
            c.startsWith(p.trimEnd(File.separatorChar) + File.separator, ignoreCase = IS_WINDOWS)
    } catch (e: Exception) {
        false
    }

    /** Le chemin est sur le dossier personnel ou sur un lecteur : navigation autorisée. */
    fun isInRoots(f: File): Boolean = roots().any { isInside(f, it) }

    fun isProtected(f: File): Boolean = try {
        val c = f.canonicalFile
        val drive = drives().firstOrNull { isInside(c, it) }
        if (drive == null) {
            true
        } else {
            val rel = c.path.substring(drive.path.length).trimStart('\\', '/')
            val first = rel.substringBefore('\\').substringBefore('/')
            first.isNotEmpty() && PROTECTED.any { it.equals(first, ignoreCase = true) }
        }
    } catch (e: Exception) {
        true
    }

    /** Autorisé pour une modification (copie, déplacement, suppression, renommage). */
    fun isSafe(f: File): Boolean = isInRoots(f) && !isProtected(f)

    private fun isValidName(n: String): Boolean {
        if (n.isEmpty() || n.length > 255) return false
        if (n.any { it in "\\/:*?\"<>|" || it < ' ' }) return false
        if (n.endsWith(".") || n.endsWith(" ")) return false
        val stem = n.substringBefore('.').uppercase()
        val reserved = setOf("CON", "PRN", "AUX", "NUL") + (1..9).map { "COM$it" } + (1..9).map { "LPT$it" }
        return stem !in reserved
    }

    private fun visible(f: File): Boolean = showHidden || !f.isHidden

    fun list(dir: File, sort: SortBy): List<File> {
        val files = dir.listFiles()?.filter { visible(it) } ?: emptyList()
        val cmp: Comparator<File> = when (sort) {
            SortBy.NAME -> compareBy<File> { it.name.lowercase() }
            SortBy.SIZE -> compareByDescending<File> { it.length() }
            SortBy.DATE -> compareByDescending<File> { it.lastModified() }
        }
        return files.sortedWith(compareBy<File> { !it.isDirectory }.then(cmp))
    }

    private val EXT_IMAGES = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "tif", "tiff", "svg")
    private val EXT_VIDEOS = setOf("mp4", "mkv", "avi", "3gp", "webm", "mov", "flv", "wmv", "m4v")
    private val EXT_AUDIO = setOf("mp3", "wav", "ogg", "m4a", "flac", "aac", "opus", "amr", "wma")
    private val EXT_DOCS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "odt", "rtf", "epub")

    const val CATEGORY_LIMIT = 3000

    fun categoryTitle(kind: String): String = when (kind) {
        "images" -> "🖼️ Images"
        "videos" -> "🎬 Vidéos"
        "audio" -> "🎵 Musique"
        else -> "📄 Documents"
    }

    fun sortFiles(files: List<File>, sort: SortBy): List<File> = when (sort) {
        SortBy.NAME -> files.sortedBy { it.name.lowercase() }
        SortBy.SIZE -> files.sortedByDescending { it.length() }
        SortBy.DATE -> files.sortedByDescending { it.lastModified() }
    }

    /** Racine (dossier personnel ou lecteur) qui contient ce fichier. */
    fun rootFor(f: File): File = roots().firstOrNull { isInside(f, it) } ?: root

    private fun scanByExt(exts: Set<String>, limit: Int): List<File> {
        val out = ArrayList<File>()
        val stack = ArrayList<Pair<File, Int>>()
        stack.add(root to 0)
        while (stack.isNotEmpty() && out.size < limit) {
            val (d, depth) = stack.removeAt(stack.lastIndex)
            val children = d.listFiles() ?: continue
            for (c in children) {
                if (c.name.startsWith(".") || !visible(c)) continue
                if (c.isDirectory) {
                    if (depth == 0 && c.name.equals("AppData", ignoreCase = true)) continue
                    if (depth < 10) stack.add(c to depth + 1)
                } else if (c.extension.lowercase() in exts) {
                    out.add(c)
                    if (out.size >= limit) break
                }
            }
        }
        return out
    }

    /** Tous les fichiers d'un type (images, vidéos, musique, documents) dans le dossier personnel. */
    fun category(kind: String, limit: Int = CATEGORY_LIMIT): List<File> {
        val exts = when (kind) {
            "images" -> EXT_IMAGES
            "videos" -> EXT_VIDEOS
            "audio" -> EXT_AUDIO
            else -> EXT_DOCS
        }
        return scanByExt(exts, limit)
    }

    suspend fun search(query: String, limit: Int = 300): List<File> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        val out = ArrayList<File>()
        val stack = ArrayList<Pair<File, Int>>()
        stack.add(root to 0)
        while (stack.isNotEmpty() && out.size < limit) {
            currentCoroutineContext().ensureActive()
            val (d, depth) = stack.removeAt(stack.lastIndex)
            val children = d.listFiles() ?: continue
            for (c in children) {
                if (!visible(c)) continue
                if (c.name.lowercase().contains(q)) out.add(c)
                if (c.isDirectory && depth < 8 && !(depth == 0 && c.name.equals("AppData", ignoreCase = true))) {
                    stack.add(c to depth + 1)
                }
            }
        }
        return out
    }

    fun uniqueTarget(dir: File, name: String): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            t = File(dir, "$base ($i)$ext")
            if (!t.exists()) return t
            i++
        }
    }

    fun copy(src: File, destDir: File): Boolean {
        if (!isSafe(src) || !isSafe(destDir) || !src.exists()) return false
        if (src.isDirectory && isInside(destDir, src)) return false
        val target = uniqueTarget(destDir, src.name)
        return try {
            if (src.isDirectory) src.copyRecursively(target, overwrite = false)
            else { src.copyTo(target, overwrite = false); true }
        } catch (e: Exception) {
            false
        }
    }

    fun move(src: File, destDir: File): Boolean {
        if (!isSafe(src) || !isSafe(destDir) || !src.exists()) return false
        if (src.parentFile?.canonicalPath == destDir.canonicalPath) return true
        if (src.isDirectory && isInside(destDir, src)) return false
        val target = uniqueTarget(destDir, src.name)
        if (src.renameTo(target)) return true
        return copy(src, destDir) && delete(src)
    }

    /** Sur Windows, la suppression depuis l'écran Fichiers passe par la Corbeille quand c'est possible. */
    fun delete(f: File, toTrash: Boolean = false): Boolean = try {
        if (!isSafe(f) || roots().any { it.canonicalPath == f.canonicalPath }) {
            false
        } else if (toTrash && moveToTrash(f)) {
            true
        } else {
            f.deleteRecursively()
        }
    } catch (e: Exception) {
        false
    }

    private fun moveToTrash(f: File): Boolean = try {
        java.awt.Desktop.isDesktopSupported() &&
            java.awt.Desktop.getDesktop().isSupported(java.awt.Desktop.Action.MOVE_TO_TRASH) &&
            java.awt.Desktop.getDesktop().moveToTrash(f)
    } catch (e: Exception) {
        false
    }

    fun rename(f: File, newName: String): Boolean {
        val n = newName.trim()
        if (!isValidName(n) || !isSafe(f)) return false
        val target = File(f.parentFile, n)
        // Sous Windows, changer seulement la casse (a.txt -> A.txt) est autorisé.
        if (target.exists() && target.canonicalPath != f.canonicalPath) return false
        return f.renameTo(target)
    }

    fun mkdir(parent: File, name: String): Boolean {
        val n = name.trim()
        if (!isValidName(n) || !isSafe(parent)) return false
        val d = File(parent, n)
        return !d.exists() && d.mkdir()
    }

    /** (total, libre) en octets pour le dossier personnel. */
    fun storage(): Pair<Long, Long> = try {
        val r = root
        r.totalSpace to r.usableSpace
    } catch (e: Exception) {
        0L to 0L
    }

    /** Dossier personnel + lecteurs Windows (C:, D:, clés USB, disques externes…). */
    fun volumes(): List<Volume> {
        val out = ArrayList<Volume>()
        val r = root
        out.add(Volume(HOME_LABEL, "🏠", r, safeTotal(r), safeFree(r)))
        val fsv = try { FileSystemView.getFileSystemView() } catch (e: Throwable) { null }
        for (d in drives()) {
            val total = safeTotal(d)
            if (total <= 0L) continue
            val type = try { fsv?.getSystemTypeDescription(d) ?: "" } catch (e: Throwable) { "" }
            val removable = type.contains("amov", ignoreCase = true) ||
                type.contains("remov", ignoreCase = true) || type.contains("usb", ignoreCase = true)
            val name = try { fsv?.getSystemDisplayName(d)?.takeIf { it.isNotBlank() } } catch (e: Throwable) { null }
                ?: ("Disque (" + d.path.trimEnd('\\', '/') + ")")
            out.add(Volume(name, if (removable) "🔌" else "💽", d, total, safeFree(d)))
        }
        return out
    }

    private fun safeTotal(f: File): Long = try { f.totalSpace } catch (e: Exception) { 0L }
    private fun safeFree(f: File): Long = try { f.usableSpace } catch (e: Exception) { 0L }

    fun humanSize(b: Long): String {
        if (b < 1024) return "$b o"
        val units = arrayOf("Ko", "Mo", "Go", "To")
        var v = b.toDouble()
        var i = -1
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return String.format(Locale.getDefault(), "%.1f %s", v, units[i])
    }

    fun date(ms: Long): String =
        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

    fun kind(f: File): String {
        if (f.isDirectory) return "Dossier"
        return when (val e = f.extension.lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "tif", "tiff", "svg" -> "Image"
            "mp4", "mkv", "avi", "3gp", "webm", "mov", "wmv" -> "Vidéo"
            "mp3", "wav", "ogg", "m4a", "flac", "aac", "wma" -> "Audio"
            "pdf", "doc", "docx", "txt", "xls", "xlsx", "ppt", "pptx", "odt", "csv" -> "Document"
            "zip", "rar", "7z", "tar", "gz" -> "Archive"
            "exe", "msi", "apk", "bat", "cmd" -> "Application"
            "" -> "Fichier"
            else -> e.uppercase()
        }
    }

    fun emoji(f: File): String = when (kind(f)) {
        "Dossier" -> "📁"
        "Image" -> "🖼️"
        "Vidéo" -> "🎬"
        "Audio" -> "🎵"
        "Document" -> "📄"
        "Archive" -> "🗜️"
        "Application" -> "⚙️"
        else -> "📃"
    }
}

data class Volume(val label: String, val emoji: String, val dir: File, val total: Long, val free: Long)
