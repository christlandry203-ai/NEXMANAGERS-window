package com.nexcode.nexmanager

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AppInfo(
    val label: String, val pkg: String, val apk: String, val version: String,
    val system: Boolean, val split: Boolean, val size: Long
)

data class TransferState(
    val title: String,
    val current: String = "",
    val done: Long = 0L,
    val total: Long = 0L,
    val finished: Boolean = false,
    val error: String? = null,
    val shareFile: File? = null,
    val startedAt: Long = 0L,
    val elapsedMs: Long = 0L,
    val itemIndex: Int = 0,
    val itemCount: Int = 0,
    val dest: String = ""
)

data class TransferLog(val label: String, val ok: Boolean, val summary: String, val at: Long)

class MainViewModel {

    private val viewModelScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs = Prefs

    init {
        Notifier.notify = { message = it }
        FileRepo.showHidden = prefs.getBoolean("hidden", false)
    }

    fun shutdown() { viewModelScope.cancel() }

    // 0 Accueil, 1 Fichiers, 2 Transfert, 3 Recherche, 4 Paramètres, 5 Programmes installés (sous-écran de Transfert)
    var tab by mutableStateOf(0)
    var message by mutableStateOf<String?>(null)

    var dark by mutableStateOf(prefs.getBoolean("dark", true)); private set
    var sort by mutableStateOf(
        runCatching { SortBy.valueOf(prefs.getString("sort", "NAME")) }.getOrDefault(SortBy.NAME)
    ); private set

    var base by mutableStateOf(FileRepo.root); private set
    var baseLabel by mutableStateOf(FileRepo.HOME_LABEL); private set
    var dir by mutableStateOf(FileRepo.root); private set
    var items by mutableStateOf<List<File>>(emptyList()); private set
    var storage by mutableStateOf(0L to 0L); private set
    var volumes by mutableStateOf<List<Volume>>(emptyList()); private set
    var category by mutableStateOf<String?>(null); private set
    var loading by mutableStateOf(false); private set

    var selected by mutableStateOf<Set<String>>(emptySet()); private set
    var clip by mutableStateOf<List<File>>(emptyList()); private set
    var clipCut by mutableStateOf(false); private set

    var searchQuery by mutableStateOf(""); private set
    var searchResults by mutableStateOf<List<File>>(emptyList()); private set
    var searching by mutableStateOf(false); private set
    private var searchJob: Job? = null

    var transfer by mutableStateOf<TransferState?>(null); private set
    private var transferJob: Job? = null
    var recent by mutableStateOf<List<TransferLog>>(emptyList()); private set
    var clipSize by mutableStateOf(-1L); private set
    private var lastRetry: (() -> Unit)? = null
    val canRetry: Boolean get() = lastRetry != null

    var apps by mutableStateOf<List<AppInfo>>(emptyList()); private set

    val atRoot: Boolean get() = dir.absolutePath == base.absolutePath
    val clipNeedsConfirm: Boolean get() = clip.size > 1 || clip.any { it.isDirectory } || clipCut

    fun refresh() {
        val d = dir
        val s = sort
        val cat = category
        if (cat != null) loading = true
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                val list = if (cat != null) FileRepo.sortFiles(FileRepo.category(cat), s) else FileRepo.list(d, s)
                Triple(list, FileRepo.storage(), FileRepo.volumes())
            }
            if (category == cat) items = r.first
            storage = r.second
            volumes = r.third
            loading = false
        }
    }

    private fun io(block: () -> String) {
        viewModelScope.launch {
            message = withContext(Dispatchers.IO) { block() }
            refresh()
        }
    }

    // --- Navigation ---
    fun goTo(d: File) {
        category = null
        val r = FileRepo.rootFor(d)
        base = r
        baseLabel = volumes.firstOrNull { it.dir.absolutePath == r.absolutePath }?.label
            ?: if (r.absolutePath == FileRepo.root.absolutePath) FileRepo.HOME_LABEL else r.path
        dir = d
        selected = emptySet()
        tab = 1
        refresh()
    }

    fun goToVolume(v: Volume) {
        category = null
        base = v.dir
        baseLabel = v.label
        dir = v.dir
        selected = emptySet()
        tab = 1
        refresh()
    }

    fun openDir(d: File) {
        if (d.isDirectory) { dir = d; selected = emptySet(); refresh() }
    }

    fun up() {
        val p = dir.parentFile
        if (!atRoot && p != null && FileRepo.isInRoots(p)) { dir = p; selected = emptySet(); refresh() }
    }

    /** Affiche tous les fichiers d'un type (images, videos, audio, documents), quel que soit leur dossier. */
    fun openCategory(kind: String) {
        category = kind
        selected = emptySet()
        items = emptyList()
        tab = 1
        refresh()
    }

    fun leaveCategory() {
        category = null
        selected = emptySet()
        tab = 0
        refresh()
    }

    fun showInFolder(f: File) {
        val parent = f.parentFile ?: return
        val r = FileRepo.rootFor(f)
        val vol = volumes.firstOrNull { it.dir.absolutePath == r.absolutePath }
        base = r
        baseLabel = vol?.label ?: FileRepo.HOME_LABEL
        dir = parent
        category = null
        selected = emptySet()
        tab = 1
        refresh()
    }

    fun browse(folderType: String?) {
        val f = folderType?.let { KnownDirs.resolve(it) }
        goTo(if (f != null && f.isDirectory) f else FileRepo.root)
    }

    // --- Réglages ---
    fun updateDark(v: Boolean) { dark = v; prefs.putBoolean("dark", v) }

    var showHidden by mutableStateOf(FileRepo.showHidden); private set

    fun updateHidden(v: Boolean) {
        showHidden = v
        FileRepo.showHidden = v
        prefs.putBoolean("hidden", v)
        refresh()
    }

    fun updateSort(s: SortBy) {
        sort = s
        prefs.putString("sort", s.name)
        refresh()
    }

    // --- Sélection ---
    fun toggleSelect(f: File) {
        val p = f.absolutePath
        selected = if (p in selected) selected - p else selected + p
    }

    fun clearSelection() { selected = emptySet() }
    fun selectOnly(f: File) { selected = setOf(f.absolutePath) }
    fun selectedFiles(): List<File> = items.filter { it.absolutePath in selected }

    // --- Actions simples ---
    fun rename(f: File, name: String) {
        io {
            if (FileRepo.rename(f, name)) "Renommé" else "Renommage impossible (nom invalide ou déjà utilisé)"
        }
    }

    fun mkdir(name: String) {
        val d = dir
        io { if (FileRepo.mkdir(d, name)) "Dossier créé" else "Création impossible" }
    }

    fun deleteMany(files: List<File>) {
        selected = emptySet()
        io {
            var ok = 0
            for (f in files) if (FileRepo.delete(f, toTrash = true)) ok++
            if (ok == files.size) "Supprimé" else "$ok/${files.size} supprimé(s)"
        }
    }

    // --- Presse-papiers ---
    fun setClip(files: List<File>, cut: Boolean) {
        clip = files
        clipCut = cut
        selected = emptySet()
        message = "${files.size} élément(s) " + if (cut) "prêt(s) à déplacer" else "prêt(s) à copier"
        computeClipSize(files)
    }

    private fun computeClipSize(files: List<File>) {
        clipSize = -1L
        viewModelScope.launch {
            val s = withContext(Dispatchers.IO) { files.sumOf { Transfer.sizeOf(it) } }
            if (clip == files) clipSize = s
        }
    }

    fun copyToClip(f: File) = setClip(listOf(f), false)
    fun cutToClip(f: File) = setClip(listOf(f), true)
    fun clearClip() { clip = emptyList(); clipSize = -1L }
    fun toggleClipMode() { if (clip.isNotEmpty()) clipCut = !clipCut }

    fun removeFromClip(f: File) {
        val n = clip.filter { it.absolutePath != f.absolutePath }
        clip = n
        if (n.isEmpty()) clipSize = -1L else computeClipSize(n)
    }

    fun selectAll() { selected = items.map { it.absolutePath }.toSet() }

    // --- Transfert (avec progression, vitesse, temps restant) ---
    private fun addLog(label: String, ok: Boolean, summary: String) {
        recent = (listOf(TransferLog(label, ok, summary, System.currentTimeMillis())) + recent).take(8)
    }

    private fun launchTransfer(
        title: String,
        itemCount: Int,
        dest: String,
        shareFile: File? = null,
        work: ((String, Long, Long) -> Unit, () -> Boolean, (Int) -> Unit) -> String?
    ) {
        if (transfer?.finished == false) return
        val started = System.currentTimeMillis()
        transfer = TransferState(title, "Préparation…", startedAt = started, itemCount = itemCount, dest = dest)
        var done = 0L
        var total = 0L
        var item = 0
        transferJob = viewModelScope.launch {
            try {
                val err = withContext(Dispatchers.IO) {
                    try {
                        work(
                            { n, d, t ->
                                done = d
                                total = t
                                transfer = TransferState(
                                    title, n, d, t, startedAt = started,
                                    itemIndex = item, itemCount = itemCount, dest = dest
                                )
                            },
                            { !isActive },
                            { i -> item = i }
                        )
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Transfer.friendly(e)
                    }
                }
                val elapsed = System.currentTimeMillis() - started
                transfer = TransferState(
                    title, finished = true, done = if (err == null) total else done, total = total,
                    error = err, shareFile = if (err == null) shareFile else null,
                    startedAt = started, elapsedMs = elapsed, itemIndex = itemCount, itemCount = itemCount, dest = dest
                )
                if (err == null) {
                    addLog(title, true, "$itemCount élément(s) · ${FileRepo.humanSize(total)} · ${Format.duration(elapsed)}")
                } else {
                    addLog(title, false, err)
                }
                refresh()
            } catch (e: CancellationException) {
                transfer = null
                message = "Transfert annulé"
                addLog(title, false, "Annulé")
                refresh()
                throw e
            }
        }
    }

    private fun destLabel(target: File): String =
        if (FileRepo.isInside(target, base)) baseLabel + target.absolutePath.removePrefix(base.absolutePath)
        else target.absolutePath

    fun paste() {
        val files = clip
        val cut = clipCut
        val target = dir
        clip = emptyList()
        clipSize = -1L
        startLocal(files, cut, target)
    }

    private fun startLocal(files: List<File>, cut: Boolean, target: File) {
        lastRetry = { startLocal(files, cut, target) }
        launchTransfer(if (cut) "Déplacement" else "Copie", files.size, destLabel(target)) { pub, canc, onItem ->
            Transfer.runLocal(files, target, cut, pub, canc, onItem)
        }
    }

    /** Destination choisie avec le sélecteur de dossier Windows (autre disque, clé USB, dossier réseau…). */
    fun transferToFolder(dest: File) {
        val files = clip
        val cut = clipCut
        if (files.isEmpty()) { message = "Rien à transférer"; return }
        clip = emptyList()
        clipSize = -1L
        startLocal(files, cut, dest)
    }

    fun cancelTransfer() { transferJob?.cancel() }

    fun retryTransfer() {
        val r = lastRetry ?: return
        transfer = null
        r()
    }

    fun dismissTransfer() {
        transfer = null
        lastRetry = null
        refresh()
    }

    // --- Programmes installés (équivalent Windows de la liste des applications Android) ---
    fun openApps() {
        tab = 5
        if (apps.isNotEmpty()) return
        viewModelScope.launch {
            apps = withContext(Dispatchers.IO) { InstalledPrograms.list() }
            if (apps.isEmpty()) message = "Impossible de lire la liste des programmes installés"
        }
    }

    /** Ouvre le dossier d'installation d'un programme dans l'Explorateur. */
    fun openInstallLocation(a: AppInfo) {
        val d = File(a.apk)
        if (a.apk.isNotBlank() && d.exists()) revealInExplorer(d) else message = "Emplacement d'installation inconnu"
    }

    /** Exporte la liste des programmes (CSV) dans Téléchargements/NEXMANAGER. */
    fun exportAppList(includeSystem: Boolean) {
        val list = apps.filter { includeSystem || !it.system }
        if (list.isEmpty()) { message = "Aucun programme à exporter"; return }
        viewModelScope.launch {
            message = withContext(Dispatchers.IO) {
                try {
                    val dl = File(KnownDirs.resolve(KnownDirs.DOWNLOADS) ?: FileRepo.root, "NEXMANAGER")
                    dl.mkdirs()
                    val target = FileRepo.uniqueTarget(dl, "Programmes_installes.csv")
                    target.writeText(InstalledPrograms.toCsv(list), Charsets.UTF_8)
                    "Liste exportée : Téléchargements\\NEXMANAGER\\${target.name}"
                } catch (e: Exception) {
                    "Export impossible : " + (e.message ?: "erreur")
                }
            }
        }
    }

    // --- Recherche ---
    fun search(q: String) {
        searchQuery = q
        searchJob?.cancel()
        if (q.isBlank()) { searchResults = emptyList(); searching = false; return }
        searchJob = viewModelScope.launch {
            searching = true
            delay(300)
            val r = withContext(Dispatchers.IO) { FileRepo.search(q) }
            searchResults = r
            searching = false
        }
    }
}
