# NEXMANAGER pour Windows

Version Windows 10 / 11 de NEXMANAGER (by NEXCODE), construite **à partir du code source Android** :
même interface (couleurs, navigation, écrans), même logique de fichiers et de transfert.
Ce dossier est un projet **séparé** : la version Android (`app/`) n'est pas modifiée.

## Technologie
Kotlin + **Compose Multiplatform for Desktop** (JetBrains), packagé avec `jpackage` :
l'installateur embarque son propre runtime Java. L'utilisateur final n'a **rien** à installer (ni Java, ni Android Studio).

## Compiler avec GitHub (recommandé)
1. Envoie le dossier `NEXMANAGER-Windows/` et le fichier `.github/workflows/build-windows.yml` dans ton dépôt.
2. Onglet **Actions** > **Build NEXMANAGER Windows** > **Run workflow** (ou simple push).
3. Quand la coche verte apparaît, ouvre l'exécution, section **Artifacts**, télécharge
   **NEXMANAGER-Windows-installateur-exe** : le zip contient `NEXMANAGER-1.2.0.exe`.
   (Aussi disponibles : le `.msi` et une version **portable** sans installation.)

## Compiler sur un PC Windows
Prérequis : JDK 17, Gradle 8.7 (ou `gradle` dans le PATH) et WiX Toolset 3 (pour le .exe / .msi).
```
cd NEXMANAGER-Windows
gradle run                     # lance l'application
gradle packageExe              # build\compose\binaries\main\exe\NEXMANAGER-1.2.0.exe
gradle createDistributable     # version portable : build\compose\binaries\main\app\NEXMANAGER\
```

## Installation
Double-clic sur `NEXMANAGER-1.2.0.exe`. L'installateur n'étant pas signé numériquement,
Windows SmartScreen peut afficher « Windows a protégé votre ordinateur » :
clique sur **Informations complémentaires** puis **Exécuter quand même**.
Installation par utilisateur (sans droits administrateur), raccourci dans le menu Démarrer (groupe NEXCODE).
Les réglages sont dans `%APPDATA%\NEXMANAGER\settings.properties`.

## Équivalences Android → Windows
| Android | Windows |
|---|---|
| Stockage interne | Dossier personnel (`C:\Users\<nom>`) |
| Carte SD / clé USB / OTG | Tous les lecteurs Windows (C:, D:, clés USB, disques externes) |
| Permission « accès à tous les fichiers » | Aucune (écran d'autorisation supprimé) |
| Dossiers Téléchargements / Documents / Images / Films / Musique / DCIM | Téléchargements / Documents / Images / Vidéos / Musique / **Bureau** |
| Choisir un dossier (SAF) | Sélecteur de dossier Windows |
| Partager (menu Android) | **Afficher dans l'Explorateur** |
| Ouvrir avec une application | Application par défaut de Windows |
| Applications installées + export d'APK | **Programmes installés** + ouvrir le dossier + export de la liste en CSV |
| Suppression définitive | **Corbeille** de Windows |
| Bouton Retour | Alt + ← |
| Index média Android (MediaStore) | Analyse du dossier personnel |
| Fichiers système Android protégés | Dossiers Windows protégés (Windows, Program Files, ProgramData…) |
| — | Nouveau : réglage « Afficher les fichiers cachés » |

Raccourcis clavier, clic droit, glisser dans les panneaux et mise en page à deux/trois panneaux : repris tels quels.
