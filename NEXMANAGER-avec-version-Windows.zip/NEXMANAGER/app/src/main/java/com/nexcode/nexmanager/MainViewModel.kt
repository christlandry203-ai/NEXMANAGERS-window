package com.nexcode.nexmanager

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class AppInfo(
    val label: String, val pkg: String, val apk: String, val version: String,
    val system: Boolean, val split: Boolean, val size: Long
)

data class TransferState(
    val title: String,
    val current: String = "",
    val done: Long = 0L,
    val total: Long = 0L,
    val finished: Boolean = false,
    val error: String? = null,
    val shareFile: File? = null,
    val startedAt: Long = 0L,
    val elapsedMs: Long = 0L,
    val itemIndex: Int = 0,
    val itemCount: Int = 0,
    val dest: String = ""
)

data class TransferLog(val label: String, val ok: Boolean, val summary: String, val at: Long)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("nexmanager", Context.MODE_PRIVATE)

    // 0 Accueil, 1 Fichiers, 2 Transfert, 3 Recherche, 4 Paramètres, 5 Applications (sous-écran de Transfert)
    var tab by mutableStateOf(0)
    var message by mutableStateOf<String?>(null)

    var dark by mutableStateOf(prefs.getBoolean("dark", true)); private set
    var sort by mutableStateOf(
        runCatching { SortBy.valueOf(prefs.getString("sort", "NAME") ?: "NAME") }.getOrDefault(SortBy.NAME)
    ); private set

    var base by mutableStateOf(FileRepo.root); private set
    var baseLabel by mutableStateOf("Stockage interne"); private set
    var dir by mutableStateOf(FileRepo.root); private set
    var items by mutableStateOf<List<File>>(emptyList()); private set
    var storage by mutableStateOf(0L to 0L); private set
    var volumes by mutableStateOf<List<Volume>>(emptyList()); private set
    var category by mutableStateOf<String?>(null); private set
    var loading by mutableStateOf(false); private set

    var selected by mutableStateOf<Set<String>>(emptySet()); private set
    var clip by mutableStateOf<List<File>>(emptyList()); private set
    var clipCut by mutableStateOf(false); private set

    var searchQuery by mutableStateOf(""); private set
    var searchResults by mutableStateOf<List<File>>(emptyList()); private set
    var searching by mutableStateOf(false); private set
    private var searchJob: Job? = null

    var transfer by mutableStateOf<TransferState?>(null); private set
    private var transferJob: Job? = null
    var recent by mutableStateOf<List<TransferLog>>(emptyList()); private set
    var clipSize by mutableStateOf(-1L); private set
    private var lastRetry: (() -> Unit)? = null
    val canRetry: Boolean get() = lastRetry != null

    var apps by mutableStateOf<List<AppInfo>>(emptyList()); private set

    val atRoot: Boolean get() = dir.absolutePath == base.absolutePath
    val clipNeedsConfirm: Boolean get() = clip.size > 1 || clip.any { it.isDirectory } || clipCut

    fun refresh() {
        val d = dir
        val s = sort
        val cat = category
        if (cat != null) loading = true
        viewModelScope.launch {
            val app = getApplication<Application>()
            val r = withContext(Dispatchers.IO) {
                val list = if (cat != null) FileRepo.sortFiles(FileRepo.category(app, cat), s) else FileRepo.list(d, s)
                Triple(list, FileRepo.storage(), FileRepo.volumes(app))
            }
            if (category == cat) items = r.first
            storage = r.second
            volumes = r.third
            loading = false
        }
    }

    private fun io(block: () -> String) {
        viewModelScope.launch {
            message = withContext(Dispatchers.IO) { block() }
            refresh()
        }
    }

    // --- Navigation ---
    fun goTo(d: File) {
        category = null
        base = FileRepo.root
        baseLabel = "Stockage interne"
        dir = d
        selected = emptySet()
        tab = 1
        refresh()
    }

    fun goToVolume(v: Volume) {
        category = null
        base = v.dir
        baseLabel = v.label
        dir = v.dir
        selected = emptySet()
        tab = 1
        refresh()
    }

    fun openDir(d: File) {
        if (d.isDirectory) { dir = d; selected = emptySet(); refresh() }
    }

    fun up() {
        val p = dir.parentFile
        if (!atRoot && p != null && FileRepo.isSafe(p)) { dir = p; selected = emptySet(); refresh() }
    }

    /** Affiche tous les fichiers d'un type (images, videos, audio, documents), quel que soit leur dossier. */
    fun openCategory(kind: String) {
        category = kind
        selected = emptySet()
        items = emptyList()
        tab = 1
        refresh()
    }

    fun leaveCategory() {
        category = null
        selected = emptySet()
        tab = 0
        refresh()
    }

    fun showInFolder(f: File) {
        val parent = f.parentFile ?: return
        val r = FileRepo.rootFor(f)
        val vol = volumes.firstOrNull { it.dir.absolutePath == r.absolutePath }
        base = r
        baseLabel = vol?.label ?: "Stockage interne"
        dir = parent
        category = null
        selected = emptySet()
        tab = 1
        refresh()
    }

    @Suppress("DEPRECATION")
    fun browse(folderType: String?) {
        val f = folderType?.let { Environment.getExternalStoragePublicDirectory(it) }
        goTo(if (f != null && f.isDirectory) f else FileRepo.root)
    }

    // --- Réglages ---
    fun updateDark(v: Boolean) { dark = v; prefs.edit().putBoolean("dark", v).apply() }

    fun updateSort(s: SortBy) {
        sort = s
        prefs.edit().putString("sort", s.name).apply()
        refresh()
    }

    // --- Sélection ---
    fun toggleSelect(f: File) {
        val p = f.absolutePath
        selected = if (p in selected) selected - p else selected + p
    }

    fun clearSelection() { selected = emptySet() }
    fun selectOnly(f: File) { selected = setOf(f.absolutePath) }
    fun selectedFiles(): List<File> = items.filter { it.absolutePath in selected }

    // --- Actions simples ---
    fun rename(f: File, name: String) {
        val app = getApplication<Application>()
        io {
            val oldPath = f.absolutePath
            val newPath = File(f.parentFile, name.trim()).absolutePath
            if (FileRepo.rename(f, name)) {
                if (f.isFile || File(newPath).isFile) FileRepo.scanAndWait(app, listOf(oldPath, newPath))
                "Renommé"
            } else {
                "Renommage impossible (nom invalide ou déjà utilisé)"
            }
        }
    }

    fun mkdir(name: String) {
        val d = dir
        io { if (FileRepo.mkdir(d, name)) "Dossier créé" else "Création impossible" }
    }

    fun deleteMany(files: List<File>) {
        selected = emptySet()
        val app = getApplication<Application>()
        val filePaths = files.filter { it.isFile }.map { it.absolutePath }
        io {
            var ok = 0
            for (f in files) if (FileRepo.delete(f)) ok++
            FileRepo.scanAndWait(app, filePaths)
            if (ok == files.size) "Supprimé" else "$ok/${files.size} supprimé(s)"
        }
    }

    // --- Presse-papiers ---
    fun setClip(files: List<File>, cut: Boolean) {
        clip = files
        clipCut = cut
        selected = emptySet()
        message = "${files.size} élément(s) " + if (cut) "prêt(s) à déplacer" else "prêt(s) à copier"
        computeClipSize(files)
    }

    private fun computeClipSize(files: List<File>) {
        clipSize = -1L
        viewModelScope.launch {
            val s = withContext(Dispatchers.IO) { files.sumOf { Transfer.sizeOf(it) } }
            if (clip == files) clipSize = s
        }
    }

    fun copyToClip(f: File) = setClip(listOf(f), false)
    fun cutToClip(f: File) = setClip(listOf(f), true)
    fun clearClip() { clip = emptyList(); clipSize = -1L }
    fun toggleClipMode() { if (clip.isNotEmpty()) clipCut = !clipCut }

    fun removeFromClip(f: File) {
        val n = clip.filter { it.absolutePath != f.absolutePath }
        clip = n
        if (n.isEmpty()) clipSize = -1L else computeClipSize(n)
    }

    fun selectAll() { selected = items.map { it.absolutePath }.toSet() }

    // --- Transfert (avec progression, vitesse, temps restant) ---
    private fun addLog(label: String, ok: Boolean, summary: String) {
        recent = (listOf(TransferLog(label, ok, summary, System.currentTimeMillis())) + recent).take(8)
    }

    private fun launchTransfer(
        title: String,
        itemCount: Int,
        dest: String,
        shareFile: File? = null,
        work: ((String, Long, Long) -> Unit, () -> Boolean, (Int) -> Unit) -> String?
    ) {
        if (transfer?.finished == false) return
        val started = System.currentTimeMillis()
        transfer = TransferState(title, "Préparation…", startedAt = started, itemCount = itemCount, dest = dest)
        var done = 0L
        var total = 0L
        var item = 0
        transferJob = viewModelScope.launch {
            try {
                val err = withContext(Dispatchers.IO) {
                    try {
                        work(
                            { n, d, t ->
                                done = d
                                total = t
                                transfer = TransferState(
                                    title, n, d, t, startedAt = started,
                                    itemIndex = item, itemCount = itemCount, dest = dest
                                )
                            },
                            { !isActive },
                            { i -> item = i }
                        )
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Transfer.friendly(e)
                    }
                }
                val elapsed = System.currentTimeMillis() - started
                transfer = TransferState(
                    title, finished = true, done = if (err == null) total else done, total = total,
                    error = err, shareFile = if (err == null) shareFile else null,
                    startedAt = started, elapsedMs = elapsed, itemIndex = itemCount, itemCount = itemCount, dest = dest
                )
                if (err == null) {
                    addLog(title, true, "$itemCount élément(s) · ${FileRepo.humanSize(total)} · ${Format.duration(elapsed)}")
                } else {
                    addLog(title, false, err)
                }
                refresh()
            } catch (e: CancellationException) {
                transfer = null
                message = "Transfert annulé"
                addLog(title, false, "Annulé")
                refresh()
                throw e
            }
        }
    }

    private fun destLabel(target: File): String =
        baseLabel + target.absolutePath.removePrefix(base.absolutePath)

    fun paste() {
        val files = clip
        val cut = clipCut
        val target = dir
        clip = emptyList()
        clipSize = -1L
        startLocal(files, cut, target)
    }

    private fun startLocal(files: List<File>, cut: Boolean, target: File) {
        lastRetry = { startLocal(files, cut, target) }
        launchTransfer(if (cut) "Déplacement" else "Copie", files.size, destLabel(target)) { pub, canc, onItem ->
            Transfer.runLocal(files, target, cut, pub, canc, onItem)
        }
    }

    /** Destination choisie avec le Storage Access Framework (carte SD, clé USB…). */
    fun transferToTree(tree: Uri) {
        val files = clip
        val cut = clipCut
        if (files.isEmpty()) { message = "Rien à transférer"; return }
        clip = emptyList()
        clipSize = -1L
        startTree(files, cut, tree)
    }

    private fun startTree(files: List<File>, cut: Boolean, tree: Uri) {
        lastRetry = { startTree(files, cut, tree) }
        val ctx = getApplication<Application>()
        launchTransfer(
            if (cut) "Déplacement vers l'emplacement choisi" else "Copie vers l'emplacement choisi",
            files.size, "Emplacement choisi (SAF)"
        ) { pub, canc, onItem ->
            Transfer.runTree(ctx, files, tree, cut, pub, canc, onItem)
        }
    }

    fun cancelTransfer() { transferJob?.cancel() }

    fun retryTransfer() {
        val r = lastRetry ?: return
        transfer = null
        r()
    }

    fun dismissTransfer() {
        transfer = null
        lastRetry = null
        refresh()
    }

    // --- Applications installées ---
    fun openApps() {
        tab = 5
        if (apps.isNotEmpty()) return
        viewModelScope.launch {
            apps = withContext(Dispatchers.IO) {
                val pm = getApplication<Application>().packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
                    val ai = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
                    val version = try { pm.getPackageInfo(ai.packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
                    AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        pkg = ai.packageName,
                        apk = ai.sourceDir ?: "",
                        version = version,
                        system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                        split = !ai.splitSourceDirs.isNullOrEmpty(),
                        size = try { File(ai.sourceDir).length() } catch (e: Exception) { 0L }
                    )
                }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
            }
        }
    }

    /** Exporte l'APK (public) d'une application : dans Téléchargements/NEXMANAGER, ou vers le menu Partager. */
    fun exportApk(a: AppInfo, share: Boolean) {
        val ctx = getApplication<Application>()
        val safe = a.label.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val name = "${safe}_${a.version}.apk"
        val shareDst = File(File(ctx.cacheDir, "apk"), name)
        lastRetry = { exportApk(a, share) }
        launchTransfer(
            if (share) "Préparation de l'APK" else "Export de l'APK",
            1,
            if (share) "Partage Android" else "Téléchargements/NEXMANAGER",
            if (share) shareDst else null
        ) { pub, canc, _ ->
            val dst = if (share) {
                shareDst.parentFile?.apply { deleteRecursively(); mkdirs() }
                shareDst
            } else {
                @Suppress("DEPRECATION")
                val dl = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NEXMANAGER")
                FileRepo.uniqueTarget(dl, name)
            }
            Transfer.runApk(File(a.apk), dst, pub, canc)
        }
    }

    // --- Recherche ---
    fun search(q: String) {
        searchQuery = q
        searchJob?.cancel()
        if (q.isBlank()) { searchResults = emptyList(); searching = false; return }
        searchJob = viewModelScope.launch {
            searching = true
            delay(300)
            val r = withContext(Dispatchers.IO) { FileRepo.search(q) }
            searchResults = r
            searching = false
        }
    }
}
